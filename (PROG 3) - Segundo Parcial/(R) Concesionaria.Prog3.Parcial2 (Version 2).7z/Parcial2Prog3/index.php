<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


require_once './CLASES/Usuario.php';
require_once './CLASES/Auto.php';
require_once './CLASES/MW.php';
require_once './vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;



$app = new \Slim\App(["settings" => $config]);


///////////////////////////////////////// PRIMERA PARTE //////////////////

// PUNTO 1.     // url: http://localhost/Parcial2Prog3/usuarios     // key: usuario         value: {"correo":"lucho.moreno@live.com","clave":"123123","nombre":"Luciano","apellido":"Moreno","perfil":"propietario"}
// key: foto            archivo de foto.                            // body -> form-data.
$app->post('/usuarios', \Usuario::class . '::AltaUsuario')->add(\MW::class . '::MWVerificarVacio')->add(\MW::class . ':MWVerificarSeteados')->add(\MW::class . '::MWVerificarQueNOExista');




// PUNTO 2.     // url: http://localhost/Parcial2Prog3/         
$app->get('[/]', \Usuario::class . '::TraerTodosLosUsuarios');  
$app->get('/listado', \Usuario::class . '::ListadoFotos');  



// PUNTO 3.     // url: http://localhost/Parcial2Prog3     // key: auto         value: {"color":"verde","marca":"Ford","precio":"900000","modelo":"Mustang"}
// key: foto            archivo de foto.                            // body -> form-data.
$app->post('[/]', \Auto::class . '::AltaAuto')->add(\MW::class . ':VerificarPrecioYColor');  



// PUNTO 4.     // url: http://localhost/Parcial2Prog3/autos  
$app->get('/autos', \Auto::class . '::TraerTodosLosAutos');  


// PUNTO 5.     // url: http://localhost/Parcial2Prog3/login  
$app->post('/login', \Usuario::class . '::CrearToken')->add(\MW::class . '::MWVerificarVacio')->add(\MW::class . ':MWVerificarSeteados')->add(\MW::class . ':MWVerificarExistencia');  


// PUNTO 6.     // url: http://localhost/Parcial2Prog3/login 
$app->get('/login', \Usuario::class . '::VerificarJWTAPI');  



$app->run();