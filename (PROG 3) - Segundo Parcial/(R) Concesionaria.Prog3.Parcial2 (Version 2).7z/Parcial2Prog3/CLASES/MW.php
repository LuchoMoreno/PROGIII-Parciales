<?php

require_once './CLASES/AccesoDatos.php';
require_once './CLASES/Usuario.php';

class MW
{

  // INSTANCIA
  public function MWVerificarSeteados($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();
    $user = json_decode ($ArrayDeParametros['usuario']);

    if($user->correo != null || $user->clave != null)
    {
      $newResponse=$next($request,$response);
      echo " --- DESDE MIDDLEWARE - Comprobacion exitosa (SETEADOS)";
    }

    if ($user->correo == null && $user->clave == null)
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : AMBOS NO SETEADOS";
      $newResponse= $response->withJson($objJson,409);
    }

    if ($user->correo != null && $user->clave == null)
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : CLAVE NO SETEADA";
      $newResponse= $response->withJson($objJson,409);
    }

    if ($user->correo == null && $user->clave != null)
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : CORREO NO SETEADO";
      $newResponse= $response->withJson($objJson,409);
    }
    

    return $newResponse;
  }


  // DE CLASE - ESTATICO
  public static function MWVerificarVacio($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();
    $user = json_decode ($ArrayDeParametros['usuario']);

    if($user->correo != " " || $user->clave != " ")
    {
      $newResponse=$next($request,$response);
      echo " --- DESDE MIDDLEWARE - Comprobacion exitosa (NO VACIOS)";
    }

    if ($user->correo == " " && $user->clave == " ")
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : AMBOS VACIOS";
      $newResponse= $response->withJson($objJson,409);
    }

    if ($user->correo != " " && $user->clave == " ")
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : CLAVE VACIA";
      $newResponse= $response->withJson($objJson,409);
    }

    if ($user->correo == " " && $user->clave != " ")
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : CORREO VACIO";
      $newResponse= $response->withJson($objJson,409);
    }
    

    return $newResponse;
  }


 // INSTANCIA
  public function MWVerificarExistencia($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();
    $user = json_decode ($ArrayDeParametros['usuario']);

    $usuario = new Usuario();
    $clase = $usuario->ExisteEnBD($user->correo, $user->clave);

    if($clase->existe == true)
    {
      $newResponse=$next($request,$response);
      echo " --- DESDE MIDDLEWARE - Comprobacion exitosa (EXISTE)";
    }
    else
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : No existe el correo o la clave";
      $newResponse= $response->withJson($objJson,403);
    }

    return $newResponse;
  }


  // INSTANCIA .. ESTA FUNCION, NO SE POR QUE MOTIVO, SIEMPRE DEVUELVE LA CLAVE COMO FALSE.
  public function MWVerificarExistenciaMejorado($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();
    $user = json_decode ($ArrayDeParametros['usuario']);

    $usuario = new Usuario();


    $claseCorreo = $usuario->ExisteCorreo($user->correo);
    $claseClave = $usuario->ExisteClave($user->clave);

    if($claseCorreo->existe == true && $claseClave->existe == true)
    {
      $newResponse=$next($request,$response);
      echo " --- DESDE MIDDLEWARE - Comprobacion exitosa (EXISTE correo y clave)";
    }

    else if($claseCorreo->existe == false && $claseClave->existe == true)
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : No existe el correo";
      $newResponse= $response->withJson($objJson,403);
    }

    else if($claseCorreo->existe == true && $claseClave->existe == false)
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : No existe la clave";
      $newResponse= $response->withJson($objJson,403);
    }

    else if($claseCorreo->existe == false && $claseClave->existe == false)
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : No existe ninguno";
      $newResponse= $response->withJson($objJson,403);
    }


    return $newResponse;
  }




  // CLASE - ESTATICO
  public static function MWVerificarQueNOExista($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();
    $user = json_decode ($ArrayDeParametros['usuario']);

    $usuario = new Usuario();
    $claseCorreo = $usuario->ExisteCorreo($user->correo);

    if($claseCorreo->existe == true)
    {

      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : Ya existe ese correo";
      $newResponse= $response->withJson($objJson,403);

    }
    else
    {
      $newResponse=$next($request,$response);
      echo " --- DESDE MIDDLEWARE - Comprobacion exitosa (NO EXISTE EL CORREO)";
    }

    return $newResponse;
  }


  // INSTANCIA
  public function VerificarPrecioYColor($request,$response,$next)
  {
    $ArrayDeParametros = $request->getParsedBody();
    $auto = json_decode ($ArrayDeParametros['auto']);

    if( ($auto->precio > 60000 && $auto->precio < 500000) && ($auto->color != "azul" && $auto->color != "Azul")  )
    {
      $newResponse=$next($request,$response);
      echo " --- DESDE MIDDLEWARE - Comprobacion exitosa (PRECIO CORRECTO - COLOR CORRECTO)";
    }

    else
    {
      $objJson= new stdClass();
      $objJson->mensaje="(MIDDLEWARE) - Error : El precio o el color son incorrectos";
      $newResponse= $response->withJson($objJson,409);
    }

    return $newResponse;
  }


}
?>