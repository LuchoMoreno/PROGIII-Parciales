<?php


require_once './CLASES/AccesoDatos.php';

class Auto
{
    // (color, marca, precio y modelo
    public $id;
    public $color;
    public $marca;
    public $precio;
    public $modelo;


    public function __construct($id=null,$color=null,$marca=null,$precio=null,$modelo=null)
    {
        $this->id=$id;
        $this->color=$color;
        $this->marca=$marca;
        $this->precio=$precio;
        $this->modelo=$modelo;
    }



    public function InsertarAutoBD()
    {
        $retorno = false;

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO autos(id, color, marca, precio, modelo)"
                                                    . "VALUES(:id, :color, :marca, :precio, :modelo)");
        
        $consulta->bindValue(':id', $this->id);
        $consulta->bindValue(':color', $this->color);
        $consulta->bindValue(':marca', $this->marca);
        $consulta->bindValue(':precio', $this->precio);
        $consulta->bindValue(':modelo', $this->modelo);

        

        $consulta->execute();   

        if($consulta->rowCount() > 0) 
         {
            $retorno = true;
         }

         return $retorno;

    }
    
    public static function AltaAuto($request,$response,$next)
    {
        //obtengo el json
        $array = $request->getParsedBody();

        // decodeo lo obtenido.
        $JSONRecibido = json_decode($array['auto']);

        $auto = new Auto();
        $auto->color = $JSONRecibido->color;
        $auto->marca = $JSONRecibido->marca;
        $auto->precio = $JSONRecibido->precio;
        $auto->modelo = $JSONRecibido->modelo;

        //json de retorno
        $objJson= new stdClass();
        $objJson->Exito=TRUE;
        $objJson->Mensaje="Se pudo agregar el auto";


        $retorno = $auto->InsertarAutoBD();;
         

        if ($retorno == true)
        {
           $objJson->Exito=true;
           $objJson->Mensaje="Se pudo agregar el auto";
           $newResponse = $response->withJson($objJson,200);
        }

        if ($retorno == false)
        {
           $objJson->Exito=false;
           $objJson->Mensaje="NO SE PUDO agregar el auto";
           $newResponse = $response->withJson($objJson,418);
        }


       return $newResponse;
    }
    

    public function TraerTodosLosAutosBD()
    {
        $autos = array();
        $objetoDatos =AccesoDatos::DameUnObjetoAcceso();
        $consulta = $objetoDatos->RetornarConsulta('SELECT * FROM autos'); 
        $consulta->execute();

        while($fila = $consulta->fetch())
        {
          $auto= new Auto($fila[0],$fila[1],$fila[2],$fila[3],$fila[4]);
          array_push($autos,$auto);
        }

        return $autos;
    }




    public static function ListadoFotosAutos()
    {
        $auto=new Auto();

        $ArrayAutos= $auto->TraerTodosLosAutosBD();

        $tabla = ("<table align='center' border='1'
        <tr>
        <th> ID </th>
        <th> COLOR </th>
        <th> MARCA </th>
        <th> PRECIO </th>
        <th> MODELO </th>
        </tr>
        ");


        foreach($ArrayAutos as $us)
        {
            $tabla .= ("<tr>
            <td>". $us->id ."</td>
            <td>". $us->color ."</td>
            <td>". $us->marca ."</td>
            <td>". $us->precio ."</td>
            <td>". $us->modelo ."</td>
            </tr>");
        }

        $tabla .= "</table>";

        return $tabla;
    }



    public static function TraerTodosLosAutos($request,$response,$next)
    {
      $objJson= new stdClass();
  
      $auto = new Auto();
      $arrayAutos=$auto->TraerTodosLosAutosBD();
  
      $objJson->Exito=true;
      $objJson->Mensaje="Se recuperaron todos los autos";
      $objJson->arrayJson=$arrayAutos;
      $objJson->tabla = Auto::ListadoFotosAutos();
  
     return $response->withJson($objJson,200);
    }



}

?>