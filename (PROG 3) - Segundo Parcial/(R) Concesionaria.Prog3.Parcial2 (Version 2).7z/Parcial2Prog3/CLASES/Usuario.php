<?php


use Firebase\JWT\JWT; // ESTO LO NECESITO PARA GENERAR EL TOKEN.

require_once './CLASES/AccesoDatos.php';

class Usuario
{
    public $id;
    public $nombre;
    public $apellido;
    public $clave; //Valores que no se pueden repetir en nuestra tabla
    public $perfil;
    public $correo;//Valores que no se pueden repetir en nuestra tabla, hay que realizar una busqueda, si esta o no esta el valor con esa clave ( un booleano)
    public $foto;


    public function __construct($id=null,$correo=null,$clave=null,$nombre=null,$apellido=null,$perfil=null,$foto=null)
    {
        $this->id=$id;
        $this->correo=$correo;
        $this->clave=$clave;
        $this->nombre=$nombre;
        $this->apellido=$apellido;
        $this->perfil=$perfil;
        $this->foto=$foto;
    }



    public function InsertarUsuarioBD()
    {
        $retorno = false;


        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        // $destino = "../fotos/" . date("Ymd_His") . ".jpg";
        
        // move_uploaded_file($_FILES["foto"]["tmp_name"], $destino) ;

        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios(id, correo, clave, nombre, apellido, perfil, foto)"
                                                    . "VALUES(:id, :correo, :clave, :nombre, :apellido, :perfil, :foto)");
        
        $consulta->bindValue(':id', $this->id);
        $consulta->bindValue(':correo', $this->correo);
        $consulta->bindValue(':clave', $this->clave);
        $consulta->bindValue(':nombre', $this->nombre);
        $consulta->bindValue(':apellido', $this->apellido);
        $consulta->bindValue(':perfil', $this->perfil);
        $consulta->bindValue(':foto', $this->foto);
        //$consulta->bindValue(':foto',$destino);


        $consulta->execute();  
        
        if($consulta->rowCount() > 0) 
         {
            $retorno = true;
         }

         return $retorno;

    }
    

    public static function AltaUsuario($request,$response,$next)
    {
        //obtengo el json
        $array = $request->getParsedBody();

        // decodeo lo obtenido.
        $JSONRecibido = json_decode($array['usuario']);

        $usuario = new Usuario();
        $usuario->correo = $JSONRecibido->correo;
        $usuario->clave = $JSONRecibido->clave;
        $usuario->nombre = $JSONRecibido->nombre;
        $usuario->apellido = $JSONRecibido->apellido;
        $usuario->perfil = $JSONRecibido->perfil;


        //obtengo la foto
        $fotoArray = $request->getUploadedFiles();
        $destino="./fotos/";

        // obtengo el nombre.
        $nombre=$fotoArray['foto']->getClientFilename();

        // obtengo la extension.
        $extension= explode(".", $nombre);


        //json de retorno
        $objJson= new stdClass();
        $objJson->Exito=TRUE;
        $objJson->Mensaje="Se pudo agregar el usuario";


        $usuario->foto = $nombre;


        $retorno = $usuario->InsertarUsuarioBD();
         

        if ($retorno == true)
        {
           $fotoArray['foto']->moveTo ($destino . $extension[0] . "." . $extension[1]);
           $objJson->Exito=true;
           $objJson->Mensaje="Se pudo agregar el usuario";
           $newResponse = $response->withJson($objJson,200);
        }

        if ($retorno == false)
        {
           $objJson->Exito=false;
           $objJson->Mensaje="NO SE PUDO agregar el usuario";
           $newResponse = $response->withJson($objJson,418);
        }

       return $newResponse;

    }
    


    public function ExisteEnBD($correo,$clave)
    {
        $json = new stdClass(); 

        $json->existe = false;

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE correo=:correo && clave=:clave");        

        $consulta->bindValue(":correo",$correo);

        $consulta->bindValue(":clave",$clave);

        $consulta->execute(); 
        
        if($consulta->rowCount() == 1) 
        {
            $json->existe = true;
            $json->usuario = $consulta->fetchObject();
        }

        return $json;
    }




    public function ExisteCorreo($correo)
    {
        $json = new stdClass(); 

        $json->existe = false;

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE correo=:correo");        

        $consulta->bindValue(":correo",$correo);

        $consulta->execute(); 
        
        if($consulta->rowCount() == 1) 
        {
            $json->existe = true;
        }

        return $json;
    }



    public function ExisteClave($clave)
    {
        $json = new stdClass(); 

        $json->existe = false;

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        
        $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios WHERE clave=:clave");        

        $consulta->bindValue(":clave",$clave);

        $consulta->execute(); 
        
        if($consulta->rowCount() == 1) 
        {
            $json->existe = true;
        }

        return $json;
    }


    public function TraerTodosLosUsuariosBD()
    {
        $usuarios = array();
        $objetoDatos =AccesoDatos::DameUnObjetoAcceso();
        $consulta = $objetoDatos->RetornarConsulta('SELECT * FROM usuarios'); 
        $consulta->execute();

        while($fila = $consulta->fetch())
        {
          $user= new Usuario($fila[0],$fila[1],$fila[2],$fila[3],$fila[4],$fila[5],$fila[6]);
          array_push($usuarios,$user);
        }

        return $usuarios;
    }


    public static function TraerTodosLosUsuarios($request,$response,$next)
    {
      $objJson= new stdClass();
  
      $usuario = new Usuario();
      $arrayUsuarios=$usuario->TraerTodosLosUsuariosBD();
  
      $objJson->Exito=true;
      $objJson->Mensaje="Se recuperaron todos los usuarios";
      $objJson->arrayJson=$arrayUsuarios;
      $objJson->tabla = Usuario::ListadoFotos();
  
     return $response->withJson($objJson,200);

    }


    public static function ListadoFotos()
    {
        $user=new Usuario();

        $arrayUsuarios= $user->TraerTodosLosUsuariosBD();

        $tabla = ("<table align='center' border='1'
        <tr>
        <th> ID </th>
        <th> CORREO </th>
        <th> NOMBRE </th>
        <th> APELLIDO </th>
        <th> PERFIL </th>
        <th> FOTO </th>
        </tr>
        ");


        foreach($arrayUsuarios as $us)
        {
            $tabla .= ("<tr>
            <td>". $us->id ."</td>
            <td>". $us->correo ."</td>
            <td>". $us->nombre ."</td>
            <td>". $us->apellido ."</td>
            <td>". $us->perfil ."</td>
            <td>". "<img src=" . "./fotos/" . $us->foto ." border='0' width='300' height='100' >" ."</td>
            </tr>");
        }

        $tabla .= "</table>";
        return $tabla;
    }


    public static function CrearToken($request,$response,$next)
    {
        // SETEO EL AHORA
        $ahora = time();

        //obtengo el json
        $array = $request->getParsedBody();

        // decodeo lo obtenido.
        $JSONRecibido = json_decode($array['usuario']);

        $usuario = new Usuario();
        $objJson= new stdClass();

        $clase = $usuario->ExisteEnBD($JSONRecibido->correo, $JSONRecibido->clave);

        if ($clase->existe == true)
        {

            $payload = array(
                'iat' => $ahora,            //CUANDO SE CREO EL JWT (OPCIONAL)
                'exp' => $ahora + (1200),     //INDICA EL TIEMPO DE VENCIMIENTO DEL JWT (OPCIONAL)
                'data' => $clase->usuario,           //DATOS DEL JWT
                'app' => "API REST 2019"    //INFO DE LA APLICACION (PROPIO)
            );

            $token = JWT::encode($payload, "miClaveSecreta");

            $objJson->jwt = $token;
            $objJson->Exito=true;
            $objJson->Mensaje="El usuario existe";

            $newResponse = $response->withJson($objJson,200);
        }

        else
        {
            $objJson->jwt = false;
            $objJson->Exito = false;
            $objJson->Mensaje="El usuario NO existe"; 

            $newResponse = $response->withJson($objJson,403);
        }

  
     return $newResponse;
    }



    public static function VerificarJWTAPI($request, $response, $args)
    {
        $token = $_GET["token"];
        $obj = Usuario::VerificarJWT($token);
        return $response->withJson($obj->mensaje, $obj->status);  
    }


    public static function VerificarJWT($token)
    {
        $retorno = new stdClass();
        $retorno->mensaje = "Token validado correctamente";
        $retorno->payload = null;
        $retorno->status = 200;
        
        try
        {
            if(empty($token) || $token === "")
            {
                throw new Exception("Token vacio");
            }
            
        $decodificado = JWT::decode($token, 'miClaveSecreta', ['HS256']);
        $retorno->payload = $decodificado->data; //Me devuelvuelve la info del usuario
        $retorno->mensaje .= " , usuario {$retorno->payload->correo}";

        }

        catch(Exception $e)
        {
            $retorno->status = 403;
            $retorno->mensaje = "Token no valido!!! --> " . $e->getMessage();
        }
        
        return $retorno;
    }



  

}

?>